# It is important to store the version number in a separate file
# so that we can read it from setup.py without importing the package

FULMAR_VERSION = "0.1.6dev3"
FULMAR_DATE = "22 Nov 2021"
