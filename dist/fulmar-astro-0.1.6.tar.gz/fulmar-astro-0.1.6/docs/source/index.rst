.. FULMAR documentation master file, created by
   sphinx-quickstart on Sun Nov 21 16:21:23 2021.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.
Welcome to the documentation for:

.. image:: FULMAR_logo_title.png

**FULMAR** is an open source Python package that was created to assist RV follow-up programs by making the analysis of the light curves easier. It provides tools to correct stellar activity, to look for transits, to refine transit parameters and to visually probe signals detected in RV. Our tool aims at selecting suitable RV follow-up targets more effectively and making their analysis easier. It was build in a modular way, making new features easier to implement.


Check out the :doc:`installation` section to start using FULMAR.


.. toctree::
   :maxdepth: 2
   :caption: Contents:
   Installation
   api

.. todo::
Thank Elisa for the logo   


.. note::

   This project is under active development.